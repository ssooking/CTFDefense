#!/usr/bin/env python
import os
import sys
import time
import subprocess


def my_str(string):
    if sys.version_info[0] == 2:
        return str(string)
    if sys.version_info[0] == 3:
        return str(string, encoding='utf-8')


def fPopen(aCmd):
    p = subprocess.Popen(aCmd, shell=True, bufsize=4096, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, close_fds=True)
    sOut = my_str(p.stdout.read())
    sErr = my_str(p.stderr.read())
    return (sOut, sErr)


def main():
    sOut, sErr = fPopen("whoami")
    sOut = sOut.strip()[0:4]
    if sOut != "root":
        print("You need root user to run uninstallation!\nExit uninstallation!")
        return

    cmd = ""
    if sys.version_info[0] == 2:
        dcmd = "python uninstall_core.py -s -a -n"
    if sys.version_info[0] == 3:
        dcmd = "python3 uninstall_core.py -s -a -n"

    parent_dir, file_name = os.path.split(sys.argv[0])
    os.chdir(parent_dir)
    os.system("chmod +x ./install_files/*.py")
    os.chdir("./install_files")
    os.system(dcmd)


if __name__ == "__main__":
    main()
    sys.exit(0)
