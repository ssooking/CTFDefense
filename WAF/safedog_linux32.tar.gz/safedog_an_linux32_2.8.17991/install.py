#!/usr/bin/env python
import os
import sys
import time
import subprocess
from optparse import OptionParser
try:
    import ConfigParser
except:
    import configparser as ConfigParser
import re


def check_ip(ip):
    pattern = r"\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[    0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][    0-9]?)\b"
    if re.match(pattern, ip):
        return True
    else:
        return False


def my_str(string):
    if sys.version_info[0] == 2:
        return str(string)
    if sys.version_info[0] == 3:
        return str(string, encoding='utf-8')


def fPopen(aCmd):
    p = subprocess.Popen(aCmd, shell=True, bufsize=4096, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, close_fds=True)
    sOut = my_str(p.stdout.read())
    sErr = my_str(p.stderr.read())
    return (sOut, sErr)


def main():
    sOut, sErr = fPopen("whoami")
    sOut = sOut.strip()[0:4]
    if sOut != "root":
        print("You need root user to run installation!\nExit installation!")
        return

    dcmd = ""
    if sys.version_info[0] == 2:
        dcmd = "python install_core.py -s -a -n"
    if sys.version_info[0] == 3:
        dcmd = "python3 install_core.py -s -a -n"

    bPrivate = False
    for arg in dcmd.split(" "):
        if arg == "-p":
            bPrivate = True
            break
    if bPrivate:
        parser = OptionParser("install.py [--server_ip x.x.x.x] [--patchfile_ip x.x.x.x] [--webdog_type web_no|apache|nginx|tomcat|weblogic] [--silent]")
        parser.add_option("-s", "--server_ip",
                          action="store",
                          type="string",
                          dest="server_ip",
                          help="ip for cloud.safedog.cn"
                          )
        parser.add_option("-p", "--patchfile_ip",
                          action="store",
                          type="string",
                          dest="patchfile_ip",
                          help="ip for patchfile.safedog.cn"
                          )
    else:
        parser = OptionParser("install.py [--webdog_type web_no|apache|nginx|tomcat|weblogic] [--silent]")

    parser.add_option("-w", "--webdog_type",
                      action="store",
                      type="string",
                      dest="webdog_type",
                      help="webdog type, can be set to apche or nginx or tomcat or weblogic, set to web_no for not to install webdog"
                      )
    parser.add_option("-t", "--silent",
                      action="store_true",
                      dest="silent",
                      help="only for silent update"
                      )

    # parser.print_help()

    (option, args) = parser.parse_args(sys.argv)

    parent_dir, file_name = os.path.split(sys.argv[0])
    os.chdir(parent_dir)
    os.system("chmod +x ./install_files/*.py")
    os.chdir("./install_files")

    # print option.silent
    # print option.server_ip
    # print option.patchfile_ip
    # print option.webdog_type
    # print args
    cf = ConfigParser.ConfigParser()
    cf.read("./dependpkg/install_options.conf")

    if bPrivate:
        if option.server_ip is not None:
            if check_ip(option.server_ip):
                cf.set("general", "server_ip", option.server_ip)
                cf.set("general", "ask_server_ip_switch", "0")
            else:
                # for old param -silent
                if option.server_ip == "ilent":
                    option.silent = True
                else:
                    print("Input server_ip is illegal")
                    return

        if option.patchfile_ip is not None:
            if check_ip(option.patchfile_ip):
                cf.set("general", "independent_patchfile_ip_switch", "1")
                cf.set("general", "patchfile_ip", option.patchfile_ip)
                cf.set("general", "ask_patchfile_ip_switch", "0")
            else:
                print("Input patchfile_ip is illegal")
                return

    webdog_types = ["web_no", "apache", "nginx", "tomcat", "weblogic"]
    if option.webdog_type is not None:
        if option.webdog_type in webdog_types:
            cf.set("general", "webdog_type", option.webdog_type)
            cf.set("general", "auto_detect_webdog_switch", "0")
        else:
            print("webdog type must be apache or nginx or tomcat or weblogic or web_no")
            return

    cf.write(open("./dependpkg/install_options_tmp.conf", "w"))

    if option.silent:
        dcmd += " -silent"

    os.system(dcmd)

    return


if __name__ == "__main__":
    main()
    sys.exit(0)
