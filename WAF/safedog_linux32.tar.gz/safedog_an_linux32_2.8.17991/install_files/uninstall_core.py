#!/usr/bin/env python
import logging
import os
import sys
import time
import socket
import threading
import copy
import pickle
import subprocess
import fcntl
import struct
import signal
import shutil
import base64
import platform


class cGlobalData:
    pass


gd = cGlobalData()
gd.isTest = False
gd.isUninstallApache = False
gd.isUninstallSafedog = False
gd.isUninstallNginx = False
gd.packetType = 1


def doExit():
    sys.exit(1)
    return


def my_input(msg):
    if sys.version_info[0] == 2:
        return raw_input(msg)
    if sys.version_info[0] == 3:
        return input(msg)


def my_str(string):
    if sys.version_info[0] == 2:
        return str(string)
    if sys.version_info[0] == 3:
        return str(string, encoding='utf-8')


def fPopen(aCmd):
    p = subprocess.Popen(aCmd, shell=True, bufsize=4096, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, close_fds=True)
    sOut = my_str(p.stdout.read())
    sErr = my_str(p.stderr.read())
    return (sOut, sErr)


def my_print(msg, end):
    if platform.python_version() < "3.0.0":
        print(msg),
    else:
        print(msg, end)


def print_result(buf, type):
    print_len = 96
    lens = len(buf)
    if type == 0:
        my_print(buf, end="")
        my_print("\033[1;32;10m", end="")
        my_print(" ".ljust(print_len - lens) + "[ok]", end="")
    elif type == 1:
        my_print(buf, end="")
        my_print("\033[1;33;10m", end="")
        my_print(" ".ljust(print_len - lens) + "[warn]", end="")
    elif type == 2:
        my_print(buf, end="")
        my_print("\033[1;31;10m", end="")
        my_print(" ".ljust(print_len - lens) + "[error]", end="")
    elif type == 3:
        my_print("\033[1;32;10m", end="")
        my_print(buf, end="")
    elif type == 4:
        my_print("\033[1;33;10m", end="")
        my_print(buf, end="")

    print("\033[0m")


def uninstall_server(showType):
    if showType == 1:
        select = input("Do you uninstall Server Defense Module?[y/N]:")
        if not select == "y" or not select == "Y":
            return
    if os.path.exists("/usr/bin/uduninstall"):
        initGD()
        print_result("Collecting setup information", 0)
        fPopen("/usr/bin/sdrepo uninstall")
        sOut, sErr = fPopen("cat /etc/issue")
        sIssueRes = sOut.lower()
        iSelect = 0
        idxArrOs = 1
        while idxArrOs <= 7:
            if sIssueRes.find(gd.arrOsDes[idxArrOs]) != -1:
                iSelect = idxArrOs
                break
            else:
                idxArrOs += 1
        for sCmd in gd.arrCmds:
            # print sCmd
            sOut, sErr = fPopen(sCmd)
            if len(sOut) > 0:
                print(sOut)
            if len(sErr) > 0:
                print(sErr)
        if iSelect != 5:
            for sLnxCmd in gd.arrLnxCmds:
                sOut, sErr = fPopen(sLnxCmd)
                if len(sOut) > 0:
                    print(sOut)
                if len(sErr) > 0:
                    print(sErr)
        else:
            for sSuseCmd in gd.arrSuseCmds:
                sOut, sErr = fPopen(sSuseCmd)
                if len(sOut) > 0:
                    print(sOut)
                if len(sErr) > 0:
                    print(sErr)
        print_result("Uninstall Server Defense Module", 0)
        print("\033[1;32;10mUninstall Server Defense Module Compeletely\033[0m")
    else:
        print("Server Defense Module is not installed")


def uninstall_apache(showType):
    global gd
    if not os.path.exists("/etc/apachesd.conf"):
        print("Apache Defense Module is not installed")
        return
    sitedogname = "safedogwz_linux" + str(gd.iBit)
    os.system("chmod +x ./" + sitedogname + "/uninstall.sh")
    os.chdir("./" + sitedogname)
    os.system("./uninstall.sh 0 " + str(showType))
    os.chdir("..")


def uninstall_nginx(showType):
    global gd
    if not os.path.exists("/etc/nginxsd.conf"):
        print("Nginx Defense Module is not installed")
        return
    nginxdirname = "safedog_nginx_linux" + str(gd.iBit)
    os.system("chmod +x ./" + nginxdirname + "/uninstall.sh")
    os.chdir("./" + nginxdirname)
    os.system("./uninstall.sh  0 " + str(showType))
    os.chdir("..")


def uninstall_tomcat(showType):
    global gd
    if not os.path.exists("/etc/tomcatsd.conf"):
        print("Tomcat Defense Module is not installed")
        return
    tomcatdirname = "safedog_tomcat_linux" + str(gd.iBit)
    os.system("chmod +x ./" + tomcatdirname + "/uninstall.py")
    os.chdir("./" + tomcatdirname)
    os.system("./uninstall.py  0 " + str(showType))
    os.chdir("..")


def uninstall_weblogic(showType):
    global gd
    if not os.path.exists("/etc/weblogicsd.conf"):
        print("Weblogic Defense Module is not installed")
        return
    weblogicdirname = "safedog_weblogic_linux" + str(gd.iBit)
    os.system("chmod +x ./" + weblogicdirname + "/uninstall.py")
    os.chdir("./" + weblogicdirname)
    os.system("./uninstall.py  0 " + str(showType))
    os.chdir("..")


def uninstall_common():
    stop_server()

    fPopen("rm -rf /etc/sd_uninstall")
    fPopen("rm -f /etc/init.d/sdccboot")
    fPopen("rm -f /etc/init.d/safedog")
    fPopen("rm -f /etc/init.d/sdboot")
    fPopen("rm -f /etc/init.d/udboot")

    fPopen("rm -f /etc/rc2.d/S99sdccboot")
    fPopen("rm -f /etc/rc3.d/S99sdccboot")
    fPopen("rm -f /etc/rc4.d/S99sdccboot")
    fPopen("rm -f /etc/rc5.d/S99sdccboot")
    fPopen("rm -f /etc/rc2.d/S99udboot")
    fPopen("rm -f /etc/rc3.d/S99udboot")
    fPopen("rm -f /etc/rc4.d/S99udboot")
    fPopen("rm -f /etc/rc5.d/S99udboot")
    fPopen("rm -f /etc/rc2.d/S99sdboot")
    fPopen("rm -f /etc/rc3.d/S99sdboot")
    fPopen("rm -f /etc/rc4.d/S99sdboot")
    fPopen("rm -f /etc/rc5.d/S99sdboot")

    fPopen("rm -f /usr/bin/sdcc")
    fPopen("rm -f /usr/bin/sdmonitor")
    fPopen("rm -f /usr/bin/sd_autoexmn");
    fPopen("rm -f /usr/bin/runsdcc")
    fPopen("rm -f /usr/bin/sdccboot")
    fPopen("rm -f /usr/bin/udboot")
    fPopen("rm -f /usr/bin/udcenter")
    fPopen("rm -f /usr/bin/udpro")
    fPopen("rm -f /usr/bin/sdalarm")
    fPopen("rm -f /usr/bin/sdsetos")
    fPopen("rm -f /usr/bin/safedog_uninstall")
    fPopen("rm -rf /usr/bin/safedog")
    fPopen("rm -rf /usr/bin/sdboot")
    fPopen("rm -f /usr/bin/sdstart")
    fPopen("rm -f /usr/bin/sdsvrd")
    fPopen("rm -f /usr/bin/sdwebdir")
    fPopen("rm -f /usr/bin/sdrtdefendupdate")
    fPopen("rm -f /usr/bin/sdcmd")
    fPopen("rm -f /usr/bin/sdtest")
    fPopen("rm -f /usr/bin/sdui")
    fPopen("rm -f /usr/bin/sduibin")
    fPopen("rm -f /usr/bin/sdcloud")
    fPopen("rm -f /usr/bin/udinstall")
    fPopen("rm -f /usr/bin/sdacm")
    fPopen("rm -f /usr/bin/sdrepo")
    fPopen("rm -f /usr/bin/uduninstall")
    fPopen("rm -f /usr/bin/SDDownload")
    fPopen("rmmod sddev")
    fPopen("rm -f /etc/sdinfo.conf")
    fPopen("rm -f /etc/udcenter.conf")
    # fPopen("rm -rf /sys/fs/cgroup/cpu/safedog")
    # fPopen("rm -rf /cgroup/cpu/safedog")


def stop_server():
    fPopen("rmmod sddev")
    fPopen("sdmonitor -QUIT")
    fPopen("sleep 3")
    fPopen("killall -9 sdmonitor>/dev/null 2>&1")
    fPopen("killall sdcc >/dev/null 2>&1")
    fPopen("killall udcenter >/dev/null 2>&1")
    fPopen("sdcmd exit >/dev/null 2>&1 &")
    fPopen("killall sdcmd >/dev/null 2>&1")
    fPopen("killall sdsvrd >/dev/null 2>&1")
    fPopen("killall sdacm >/dev/null 2>&1")


def main():
    global gd
    showType = 0
    stepFollow = []
    funcSets = {"server": uninstall_server, "apache": uninstall_apache, "nginx": uninstall_nginx,
                "tomcat": uninstall_tomcat, "weblogic": uninstall_weblogic}

    gd.iBit = 0
    sOut, sErr = fPopen("getconf LONG_BIT")
    if int(sOut) == 32:
        gd.iBit = 32
    else:
        gd.iBit = 64

    gd.isOldVer = 0

    for i in range(1, len(sys.argv)):
        if sys.argv[i] == "-s":
            stepFollow.append("server")
        elif sys.argv[i] == "-a":
            stepFollow.append("apache")
        elif sys.argv[i] == "-n":
            stepFollow.append("nginx")
        elif sys.argv[i] == "-t":
            stepFollow.append("tomcat")
        elif sys.argv[i] == "-w":
            stepFollow.append("weblogic")

    stop_server()
    for key in stepFollow:
        funcSets[key](0)

    uninstall_common()
    print_result("Uninstall Common Module", 0)
    print("Uninstall completely!")

    return


def ClearHandleDbCmd():
    cmd = "[{\"dbName\":\"handlecache\",\"tableName\":\"VirusHandleIsolationInfo\",\"action\":\"batchDelete\",\"records\":[]}]"
    cmdbase = base64.b64encode(cmd.encode())
    currtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
    timebase = base64.b64encode(currtime.encode())
    return ("sdalarm -r dbOperation %s %s" % (timebase, cmdbase))


def initGD():
    global gd

    gd.arrCmds = []
    gd.arrLnxCmds = []
    gd.arrSuseCmds = []

    gd.arrOs = ['', 'ubuntu', 'centos', 'fedora', 'rhel', 'suse', 'asianux', 'debian', 'else']
    gd.arrOsDes = ['', 'ubuntu', 'centos', 'fedora', 'hat', 'suse', 'asianux', 'debian', 'else']

    gd.arrCmds.append("cgdelete cpu:/safedog >/dev/null 2>&1")
    gd.arrCmds.append("rmdir /cgroup/cpu/safedog >/dev/null 2>&1")
    gd.arrCmds.append("rmdir /sys/fs/cgroup/cpu/safedog >/dev/null 2>&1")
    if os.path.isdir("/etc/safedog/backup"):
        gd.arrCmds.append("rm -rf /etc/safedog/backup >/dev/null 2>&1")

    if (os.path.isfile("/etc/safedog/server/conf/handlecache.db") or
            (os.path.isfile("/etc/safedog/server/examine/isolation_list.conf")
             and os.path.isdir("/etc/safedog/server/examine/isolation_files")
             and len(os.listdir("/etc/safedog/server/examine/isolation_files")) > 0)):
        r = my_input("Would you like to backup the files of isolation?[y/n](default:y):")
        if r == "N" or r == "n":
            print("remove files of isolation ")
            gd.arrCmds.append(ClearHandleDbCmd())
        else:
            gd.arrCmds.append("mkdir -p /etc/safedog/backup >/dev/null 2>&1")
            gd.arrCmds.append("mkdir -p /etc/safedog/backup/isolation_info_bak/isolation_files >/dev/null 2>&1")
            gd.arrCmds.append(
                "mv /etc/safedog/server/examine/isolation_list.conf /etc/safedog/backup/isolation_info_bak/ >/dev/null 2>&1")
            gd.arrCmds.append(
                "mv /etc/safedog/server/examine/isolation_files/*  /etc/safedog/backup/isolation_info_bak/isolation_files/ >/dev/null 2>&1")
            gd.arrCmds.append(
                "mv /etc/safedog/server/conf/handlecache.db  /etc/safedog/backup/isolation_info_bak/ >/dev/null 2>&1")
    r = my_input("Would you like to backup safedog logs?[y/n](default:y):")
    if r == "N" or r == "n":
        print("remove safedog logs")
        gd.arrCmds.append("rm -rf /etc/safedog/logs >/dev/null 2>&1")
    else:
        gd.arrCmds.append("mkdir -p /etc/safedog/backup >/dev/null 2>&1")
        gd.arrCmds.append("mv /etc/safedog/logs /etc/safedog/backup/ >/dev/null 2>&1")

    if gd.isTest:
        if gd.iBit == 32:
            gd.arrCmds.append("uduninstall NF-7400L test")
        else:
            gd.arrCmds.append("uduninstall NF-7400L64 test")
    else:
        if gd.iBit == 32:
            gd.arrCmds.append("uduninstall NF-7400L")
        else:
            gd.arrCmds.append("uduninstall NF-7400L64")

    gd.arrCmds.append("rm -rf /etc/safedog/server")
    gd.arrCmds.append("rm -rf /etc/safedog/sdcc")
    gd.arrCmds.append("rm -rf /etc/safedog/logs")
    gd.arrCmds.append("rm -rf /etc/safedog/libs")
    gd.arrCmds.append("rm -rf /etc/safedog/script")
    gd.arrCmds.append("rm -rf /etc/safedog/bin")
    gd.arrCmds.append("rm -rf /etc/safedog/conf")
    gd.arrCmds.append("rm -rf /etc/cloudhelper")
    # gd.arrCmds.append("rm -rf /etc/safedog")

    if not gd.isTest:
        gd.arrCmds.append("date >> /etc/sduninstall.log")
    return


if __name__ == "__main__":
    main()
    os._exit(0)
