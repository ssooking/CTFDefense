#!/bin/bash

$g_ExistNginx
$g_ExistApache
$g_ExistTomcat
$g_ExistWeblogic
declare -i g_BackResult=0


#check weblogic
function check_weblogic()
{
	g_ExistWeblogic="false"
	#"checking nginx process"
	for progname in weblogic  
	do
		g_WeblogicPath=`ps -ef | grep $progname |grep java | awk '{print $8}'`
		if [ "$g_WeblogicPath" != "" ];then
			g_ExistWeblogic="true"
		else
			g_WeblogicPath=`locate -er /weblogic.jar$`
			if [ "$g_WeblogicPath" != "" ];then
				g_ExistWeblogic="true"
			fi
		fi
	done
}

#check tomcat
function check_tomcat()
{
	g_ExistTomcat="false"
	#"checking nginx process"
	for progname in tomcat  
	do
		g_TomcatPath=`ps -ef | grep $progname |grep java | awk '{print $8}'`
		if [ "$g_TomcatPath" != "" ];then
			g_ExistTomcat="true"
		else
			g_TomcatPath=`locate -er /catalina.sh$`
			if [ "$g_TomcatPath" != "" ];then
				g_ExistTomcat="true"
			fi
		fi
	done
}

#check Nginx
function check_Nginx()
{
	g_ExistNginx="false"

	#"checking nginx process"
	for progname in nginx  
	do 			
		g_NginxExePath=`ps -ef | grep $progname | grep master | awk '{print $11}'`
		if [ ! -z $g_NginxExePath ];then
			g_ExistNginx="true"
		fi
	done	
}


#check apache
function check_apache()
{
	for progname in httpd apache2 apached
	do 		
		#checking apache service
		testcmd="service "$progname" status"
		$testcmd>/dev/null 2>&1
		ret=$?
		if [ "$ret" == "0" ] || [ "$ret" == "2" ] || [ "$ret" == "3" ]; then
			g_ExistApache="true"
			return  1
		else
			testcmd="service "$progname" stop"
			$testcmd>/dev/null 2>&1
			ret=$?
			if [ "$ret" == "0" ]; then
				g_ExistApache="true"
				return  1
			fi
		fi
		
		#"checking apache process"
		g_ApacheExePath=`ps -ef | grep $progname | grep -v grep | tail -3 | head -1 | awk '{print $8}'`
		if [ ! -z $g_ApacheExePath ];then
			g_ExistApache="true"
			return 1
		fi
		
	done

	# not found
	g_ExistApache="false"
}

check_Nginx
check_apache
check_tomcat
check_weblogic

g_BackResult=0

if [ $g_ExistApache = "true" ];then
	g_BackResult=$g_BackResult+1
fi

if [ $g_ExistNginx = "true" ];then
	g_BackResult=$g_BackResult+2
fi

if [ $g_ExistTomcat = "true" ];then
	g_BackResult=$g_BackResult+4
fi

if [ $g_ExistWeblogic = "true" ];then
	g_BackResult=$g_BackResult+8
fi


echo $g_BackResult
exit $g_BackResult
