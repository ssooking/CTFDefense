#!/usr/bin/env python
import os,sys,time,subprocess

def main():
    cmd=""
    if(len(sys.argv)==2):
        if(sys.version_info[0] == 2):
            cmd="python uninstall_2x.py"+" "+sys.argv[1]
        if(sys.version_info[0] == 3):
            cmd="python uninstall_3x.py"+" "+sys.argv[1]
    else:
        if(sys.version_info[0] == 2):
            cmd="python uninstall_2x.py"
        if(sys.version_info[0] == 3):
            cmd="python uninstall_3x.py"
    
    os.system("chmod +x /etc/sd_uninstall/install_files/*.py")
    os.chdir("/etc/sd_uninstall/install_files")
    os.system(cmd)

if __name__ == "__main__":
    main()
    sys.exit(0)
